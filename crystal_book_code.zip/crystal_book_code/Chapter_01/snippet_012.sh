crystal spec --order random --fail-fast
