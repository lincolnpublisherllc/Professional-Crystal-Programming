  crystal build src/app.cr --release
