crystal run src/app.cr --stats
