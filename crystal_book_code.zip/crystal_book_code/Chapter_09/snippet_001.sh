crystal build src/app.cr --debug
