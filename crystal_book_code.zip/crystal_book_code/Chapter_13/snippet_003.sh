crystal spec
